<?php return array (
  'backend.admins.admin-search' => 'App\\Http\\Livewire\\Backend\\Admins\\AdminSearch',
  'backend.admins.create' => 'App\\Http\\Livewire\\Backend\\Admins\\Create',
  'backend.admins.update' => 'App\\Http\\Livewire\\Backend\\Admins\\Update',
);