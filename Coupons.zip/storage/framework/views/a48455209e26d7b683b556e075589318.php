<form>
    <!-- 1 -->
    <div class="form-group">
        <label for="current-password"></label>
        <input id="current-password" type="password" class="form-control"
            style="<?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            border-color: rgb(230, 22, 22);
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            name="current-password" wire:model="current_password" placeholder="<?php echo e(__('Current Password')); ?>" required
            autofocus>
        <span toggle="#password" class="toggle-password fa fa-fw fa-eye" data-target="#password1"></span>
    </div>
    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: rgb(230, 22, 22);"><?php echo e(__($message)); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <!-- 2 -->
    <div class="form-group">
        <label for="new_password"></label>
        <input id="new_password" wire:model="new_password" type="password" class="form-control" name="new_password"
            placeholder="<?php echo e(__('New Password')); ?>" required autofocus
            style="<?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            border-color: rgb(230, 22, 22);
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <span toggle="#password" class="toggle-password fa fa-fw fa-eye" data-target="#password2"></span>
    </div>
    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: rgb(230, 22, 22);"><?php echo e(__($message)); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="form-group">
        <label for="new_password_confirmation"></label>
        <input id="new_password_confirmation" wire:model="new_password_confirmation" type="password"
            class="form-control" name="new_password_confirmation" placeholder="<?php echo e(__('New Password Confirmation')); ?>"
            required autofocus>
        <span toggle="#password" class="toggle-password fa fa-fw fa-eye" data-target="#password3"></span>
    </div>

    <div class="form-group no-margin">
        <button type="button" wire:click="updatePassword()" class="btn btn-primary btn-block">
            <?php echo e(__('Change password')); ?>

        </button>
    </div>

    <?php if($msgStatus == 'error'): ?>
        <div class="alert alert-danger form-group" role="alert">
            <?php echo e(__($msg)); ?>

        </div>
    <?php elseif($msgStatus == 'success'): ?>
        <div class="alert alert-primary form-group" role="alert">
            <?php echo e(__($msg)); ?>

        </div>
    <?php endif; ?>
</form>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/livewire/front/auth/change-password.blade.php ENDPATH**/ ?>