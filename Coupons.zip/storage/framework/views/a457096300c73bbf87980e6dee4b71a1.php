<div class="col-sm-6 col-12  py-1">
    <button class="btn btn-primary waves-effect waves-float waves-light" type="<?php echo e($type); ?>"
        wire:click="<?php echo e($action); ?>"><?php echo e(__($text)); ?></button>
    <button class="btn btn-secondary waves-effect waves-float waves-light" type="reset"><?php echo e(__('Cancel')); ?></button>
</div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/components/form/submit.blade.php ENDPATH**/ ?>