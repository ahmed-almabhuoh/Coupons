<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Font Awsome  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <!-- Css File -->
    <?php if(session('lang') == 'ar'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('front/pages/css/master-rtl.css')); ?>" />
        
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('front/pages/css/master.css')); ?>" />
        
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('front/pages/css/bootstrap.min.css')); ?>" />
    <!-- Title Page -->

    <?php echo $__env->yieldContent('styles'); ?>

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <!-- ================Start Header============== -->
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <div class="logo">
                <?php
                    $logo = DB::table('website_settings')
                        ->orderByDESC('created_at')
                        ->first()->logo;
                ?>
                <img src="<?php echo e(env('APP_URL') . 'content/' . $logo); ?>" alt="" style="width: 50px; height: 50px;"
                    class="website-logo">
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main"
                aria-controls="main" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="main">

                <?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </nav>
    <!-- ================End Header============== -->

    <!-- ================Start Main Section============== -->
    <div class="sections  d-flex">
        <!-- Start Sidebar -->
        <sidebar class="sidebar">
            <div class="d-flex flex-column flex-shrink-0 p-3 bg-light">

                <ul class="nav pt-5 nav-pills flex-column mb-auto ">

                    <li class="nav-item pb-2 ">
                        <a href="<?php echo e(route('users.account')); ?>"
                            class="nav-link text-black-50 <?php if(Route::currentRouteName() == 'users.account'): ?> active <?php endif; ?>"
                            aria-current="page">
                            <i class="fa-solid fa-user"></i>
                            <span><?php echo e(__('My Account')); ?></span>
                        </a>
                    </li>

                    <li class="pb-2">
                        <a href="<?php echo e(route('users.favorite')); ?>"
                            class="nav-link link-dark text-black-50  <?php if(Route::currentRouteName() == 'users.favorite'): ?> active <?php endif; ?>">
                            <i class="fa-solid fa-bag-shopping"></i>
                            <span><?php echo e(__('Favorite')); ?></span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('users.change.password')); ?>"
                            class="nav-link link-dark text-black-50 <?php if(Route::currentRouteName() == 'users.change.password'): ?> active <?php endif; ?>">
                            <i class="fa-solid fa-gear"></i>
                            <span><?php echo e(__('Change Password')); ?></span>
                        </a>
                    </li>

                </ul>

            </div>
        </sidebar>
        <!-- End Sidebar -->
        <!-- ====================== -->


        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- ================End Main Section============== -->


    <!--=============== Start Footer =============== -->
    <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=============== End Footer =========== -->
    <script src="<?php echo e(asset('front/pages/js/script.js')); ?>"></script>
    <script defer src="https://use.fontawesome.com/releases/v6.4.0/js/all.js"
        integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('front/pages/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front/pages/js/all.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/layouts/client-pages.blade.php ENDPATH**/ ?>