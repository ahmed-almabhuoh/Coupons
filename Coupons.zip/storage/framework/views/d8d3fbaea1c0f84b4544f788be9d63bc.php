<?php $__env->startSection('title', __('Assign Permissions')); ?>
<?php $__env->startSection('page-index', __('Assign Permissions')); ?>
<?php $__env->startSection('root', __('List')); ?>
<?php $__env->startSection('sub-root', __('HR')); ?>


<?php $__env->startSection('styles'); ?>
    <!-- BEGIN: Vendor CSS-->
    
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('panel/app-assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('panel/app-assets/vendors/css/tables/datatable/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('panel/app-assets/vendors/css/tables/datatable/buttons.bootstrap5.min.css')); ?>">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('panel/assets/css/style.css')); ?>">
    <!-- END: Custom CSS-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-body">
        <!-- users list start -->
        <section class="app-user-list">
            <div class="card">

                <div class="card-datatable table-responsive pt-0">
                    <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer">
                        <table class="user-list-table table dataTable no-footer dtr-column" id="DataTables_Table_0"
                            role="grid" aria-describedby="DataTables_Table_0_info">
                            <thead class="table-light">
                                <tr role="row">
                                    <th class="control sorting_disabled" rowspan="1" colspan="1"
                                        style="width: 31.6562px; display: none;" aria-label=""></th>
                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1"
                                        colspan="1" style="width: 101.266px;"
                                        aria-label="User: activate to sort column ascending">
                                        <?php echo e(__('Permission name')); ?></th>
                                    <th class="sorting_disabled" rowspan="1" colspan="1" style="width: 135.891px;"
                                        aria-label="Actions"> <?php echo e(__('Actions')); ?> </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!count($permissions)): ?>
                                    <tr class="odd">
                                        <td valign="top" colspan="6" class="dataTables_empty">
                                            <?php echo e(__('No permissions found yet ... !')); ?> </td>
                                    </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if(auth()->user()->lang == 'en'): ?>
                                            <td><?php echo e($permission->name); ?></td>
                                        <?php elseif(auth()->user()->lang == 'ar'): ?>
                                            <td><?php echo e($permission->name_ar); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <input type="checkbox"
                                                onchange="assignPermissionToRole('<?php echo e(Crypt::encrypt($role->id)); ?>', '<?php echo e(Crypt::encrypt($permission->id)); ?>')"
                                                class="form-check-input" id="permission_<?php echo e($permission->id); ?>"
                                                <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission_role->id == $permission->id): ?>
                                                        checked
                                                    <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-between mx-2 row mb-1">
                            <?php echo e($permissions->links()); ?>

                        </div>
                    </div>
                </div>


                <!-- Modal to add new user Ends-->
            </div>
            <!-- list section end -->
        </section>
        <!-- users list ends -->

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('panel/app-assets/js/scripts/pages/app-user-list.js')); ?>"></script>
    <!-- END: Page JS-->

    <script>
        function confirmationDelete(id, refrance, lang = 'ar') {

            var title, text, confirmButtonText, cancelButtonText;
            if (lang == "ar") {
                title = "هل أنت متأكد؟";
                text = "لن تتمكن من التراجع عن هذا!";
                confirmButtonText = "نعم، احذفها";
                cancelButtonText = "لا، ألغِ الأمر";
            } else {
                title = "Are you sure?";
                text = "You won't be able to revert this!";
                confirmButtonText = "Yes, delete it!";
                cancelButtonText = "No, cancel";
            }

            Swal.fire({
                title: title,
                text: text,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: confirmButtonText,
                cancelButtonText: cancelButtonText
            }).then((result) => {
                if (result.isConfirmed) {
                    deleteAdmin(id, refrance);
                }
            })
        }

        function deleteAdmin(id, refrance) {
            axios.delete('/cpanel/roles/destroy/' + id)
                .then((response) => {
                    // console.log('Response:', response.data);
                    toastr.success(response.data.body, response.data.header);
                    refrance.closest('tr').remove();
                    showDeletingMessage(response.data);
                })
                .catch((error) => {
                    // console.error('Error:', error);
                    toastr.error(error.response.data.body, error.response.data.header);
                    showDeletingMessage(error.response.data);
                });
        }

        function showDeletingMessage(data) {
            Swal.fire({
                icon: data.icon,
                title: data.title,
                text: data.text,
                showConfirmButton: false,
                timer: 4000
            });
        }

        function assignPermissionToRole(role_id, permission_id) {
            axios.get('/cpanel/roles/assign-permission/' + role_id + '/' + permission_id)
                .then((response) => {
                    // console.log('Response:', response.data);
                    toastr.success(response.data.body, response.data.header);
                })
                .catch((error) => {
                    // console.error('Error:', error);
                    toastr.error(error.response.data.body, error.response.data.header);
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/roles/assign-permissions.blade.php ENDPATH**/ ?>