<?php $__env->startSection('title', __('Update') . ' ' . $blog->title); ?>
<?php $__env->startSection('page-index', __('Blogs')); ?>
<?php $__env->startSection('root', __('Update')); ?>
<?php $__env->startSection('sub-root', __('CM')); ?>

<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('panel/app-assets/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('panel/app-assets/vendors/css/extensions/swiper.min.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('panel/app-assets/css/core/menu/menu-types/vertical-menu.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('panel/app-assets/css/plugins/extensions/ext-component-swiper.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Update') . ' ' . $blog->name); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.blogs.update', ['blog' => $blog,'categories' => $categories,'stores' => $stores])->html();
} elseif ($_instance->childHasBeenRendered('fKdgV0L')) {
    $componentId = $_instance->getRenderedChildComponentId('fKdgV0L');
    $componentTag = $_instance->getRenderedChildComponentTagName('fKdgV0L');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fKdgV0L');
} else {
    $response = \Livewire\Livewire::mount('backend.blogs.update', ['blog' => $blog,'categories' => $categories,'stores' => $stores]);
    $html = $response->html();
    $_instance->logRenderedChild('fKdgV0L', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('panel/app-assets/vendors/js/extensions/swiper.min.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('panel/app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('panel/app-assets/js/core/app.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('panel/app-assets/js/scripts/extensions/ext-component-swiper.js')); ?>"></script>
    <!-- END: Page JS-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/blogs/edit.blade.php ENDPATH**/ ?>