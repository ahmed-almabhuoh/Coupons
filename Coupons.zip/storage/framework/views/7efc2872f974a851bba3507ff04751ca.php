<div class="col-sm-6 col-12  py-1">
    <label class="form-label" for="<?php echo e($id ?? $name); ?>"><?php echo e(__($label)); ?></label>
    <input type="<?php echo e($type); ?>" wire:model="<?php echo e($model ?? $name); ?>"
        class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    is-invalid
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="<?php echo e($name); ?>" id="<?php echo e($id ?? $name); ?>"
        value="<?php echo e($value); ?>" placeholder="<?php echo e(__($placeholder) ?? __('Enter the ' . $name)); ?>"
        <?php if($isRequired): ?> required="" <?php endif; ?> <?php if($readOnly): ?> readonly <?php endif; ?> />
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e(__($message)); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
</div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/components/form/input.blade.php ENDPATH**/ ?>