<div class="col-sm-6 col-12  py-1">
    <label class="form-label" for="<?php echo e($id ?? $name); ?>"><?php echo e(__($label)); ?></label>
    <input type="<?php echo e($type); ?>" wire:model="<?php echo e($model ?? $name); ?>" min="<?php echo e($type == 'number' ? $min ?? 0 : ''); ?>"
        max="<?php echo e($type == 'number' ? $max ?? 100 : ''); ?>"
        class="form-control <?php $__errorArgs = [$model ?? $name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    is-invalid
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="<?php echo e($name); ?>"
        id="<?php echo e($id ?? $name); ?>" placeholder="<?php echo e(__($placeholder) ?? __('Enter the ' . $name)); ?>" 
         <?php if($type == 'number'): ?> pattern="[0-9]+" <?php endif; ?> />
    <?php if($desc ?? false): ?>
        <small class="text-muted"><?php echo e(__($desc) ?? ''); ?></small>
    <?php endif; ?>
    <?php $__errorArgs = [$model ?? $name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e(__($message)); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/components/form/input.blade.php ENDPATH**/ ?>