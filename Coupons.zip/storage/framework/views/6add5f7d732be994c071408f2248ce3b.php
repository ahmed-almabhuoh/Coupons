<div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                            data-bs-toggle="dropdown" aria-expanded="false" title="Platform">
                            <?php echo e(__('Filter by Platform')); ?>

                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a class="dropdown-item" wire:click="filterByPlatform('<?php echo e($store->id); ?>')"
                                        href="#"><?php echo e($store->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </th>
                <th scope="col">
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(__('Filter by Status')); ?>

                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton2">
                            <li><a class="dropdown-item" href="#" wire:click="filterByStatus('active')">
                                    <?php echo e(__('Active')); ?>

                                </a></li>
                            <li><a class="dropdown-item" href="#" wire:click="filterByStatus('draft')">
                                    <?php echo e(__('Inactive')); ?> </a></li>
                        </ul>
                    </div>
                </th>
                <th scope="col">
                    <label for="searchInput" class="visually-hidden"> <?php echo e(__('Search')); ?> </label>
                    <input type="text" id="searchInput" class="form-control" wire:model="searchTerm"
                        placeholder="<?php echo e(__('Find what You want..')); ?>">
                </th>
            </tr>
            <tr>
                <th class="header-tabel" scope="col"> <?php echo e(__('Coupon')); ?> </th>
                <th class="header-tabel" scope="col"> <?php echo e(__('Platform name')); ?> </th>
                <th class="header-tabel" scope="col"> <?php echo e(__('Discount')); ?> </th>
                <th class="header-tabel" scope="col"> <?php echo e(__('Status')); ?> </th>
                <th class="header-tabel" scope="col"> <?php echo e(__('Commands')); ?> </th>
            </tr>
        </thead>
        <tbody>
            <?php if(!count($favorites)): ?>
                <tr>
                    <td colspan="5"><?php echo e(__('Favorite is empty right now, start browsing and using coupons :(')); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row" class="text-black fw-normal">
                        <?php if($favorite->coupon): ?>
                            <?php echo e($favorite->coupon->code); ?>

                        <?php elseif($favorite->product): ?>
                            <?php echo e($favorite->product->name); ?>

                        <?php endif; ?>
                    </th>
                    <td>
                        <?php if($favorite->coupon): ?>
                            <?php echo e($favorite->coupon->store->name); ?>

                        <?php elseif($favorite->product): ?>
                            <?php echo e($favorite->product->store->name); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($favorite->coupon): ?>
                            <?php echo e($favorite->coupon->discount . '%'); ?>

                        <?php elseif($favorite->product): ?>
                            <?php echo e($favorite->product->offer . '%'); ?>

                        <?php endif; ?>
                    </td>
                    <?php if($favorite->coupon): ?>
                        <td class="<?php if($favorite->coupon->status == 'active'): ?> green-text <?php else: ?> red-text <?php endif; ?>">
                            <?php echo e(__(ucfirst($favorite->coupon->status))); ?></td>
                    <?php elseif($favorite->product): ?>
                        <td class="<?php if($favorite->product->status == 'active'): ?> green-text <?php else: ?> red-text <?php endif; ?>">
                            <?php echo e(__(ucfirst($favorite->product->status))); ?></td>
                    <?php endif; ?>

                    
                    <?php if($favorite->coupon): ?>
                        <td class="btn" id="copying_button" onclick="copyCode(<?php echo e($favorite); ?>)">
                            <?php echo e(__('Copy')); ?> </td>
                    <?php elseif($favorite->product): ?>
                        <td class="btn" id="copying_button" onclick="copyCode(<?php echo e($favorite); ?>)">
                            <?php echo e(__('Copy')); ?> </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        

        <div class="paginator">
            <?php echo e($favorites->links()); ?>

        </div>
    </table>

</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        function copyCode(favorite) {
            // var btn = document.getElementById('copying_button');
            if (favorite.coupon) {
                navigator.clipboard.writeText(favorite.coupon.code)
                    .then(() => {
                        alert("Code copied to clipboard");
                    })
                    .catch((error) => {
                        alert("Failed to copy text: ", error);
                    });
            } else {
                navigator.clipboard.writeText(favorite.product.name)
                    .then(() => {
                        alert("Code copied to clipboard");
                    })
                    .catch((error) => {
                        alert("Failed to copy text: ", error);
                    });
            }
            // navigator.clipboard.writeText(btn.getAttribute('value'))
            //     .then(() => {
            //         alert("Code copied to clipboard");
            //     })
            //     .catch((error) => {
            //         alert("Failed to copy text: ", error);
            //     });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/livewire/front/auth/favorite.blade.php ENDPATH**/ ?>