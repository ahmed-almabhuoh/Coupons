<?php $__env->startSection('title', __('Create a new serial')); ?>
<?php $__env->startSection('page-index', __('Serials')); ?>
<?php $__env->startSection('root', __('Create')); ?>
<?php $__env->startSection('sub-root', __('CM')); ?>


<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Create a new serial')); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.serials.create', [])->html();
} elseif ($_instance->childHasBeenRendered('5FbUQF6')) {
    $componentId = $_instance->getRenderedChildComponentId('5FbUQF6');
    $componentTag = $_instance->getRenderedChildComponentTagName('5FbUQF6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5FbUQF6');
} else {
    $response = \Livewire\Livewire::mount('backend.serials.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('5FbUQF6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('serial-created', function(data) {
                // alert(data.message);
                console.log('Here');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/serials/store.blade.php ENDPATH**/ ?>