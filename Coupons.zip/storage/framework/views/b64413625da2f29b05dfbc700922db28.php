<?php $__env->startSection('title', __('Update') . ' ' . $coupon->code); ?>
<?php $__env->startSection('page-index', __('Coupons')); ?>
<?php $__env->startSection('root', __('Update')); ?>
<?php $__env->startSection('sub-root', __('CM')); ?>

<?php $__env->startSection('styles'); ?>
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('panel/app-assets/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('panel/app-assets/vendors/css/pickers/pickadate/pickadate.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('panel/app-assets/vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('panel/app-assets/css/core/menu/menu-types/vertical-menu.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('panel/app-assets/css/plugins/forms/pickers/form-flat-pickr.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('panel/app-assets/css/plugins/forms/pickers/form-pickadate.css')); ?>">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('panel/assets/css/style.css')); ?>">
    <!-- END: Custom CSS-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Update') . ' ' . $coupon->code); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.coupons.update', ['coupon' => $coupon,'categories' => $categories,'stores' => $stores])->html();
} elseif ($_instance->childHasBeenRendered('QjROROV')) {
    $componentId = $_instance->getRenderedChildComponentId('QjROROV');
    $componentTag = $_instance->getRenderedChildComponentTagName('QjROROV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QjROROV');
} else {
    $response = \Livewire\Livewire::mount('backend.coupons.update', ['coupon' => $coupon,'categories' => $categories,'stores' => $stores]);
    $html = $response->html();
    $_instance->logRenderedChild('QjROROV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('panel/app-assets/vendors/js/pickers/pickadate/picker.js')); ?>"></script>
    <script src="<?php echo e(asset('panel/app-assets/vendors/js/pickers/pickadate/picker.date.js')); ?>"></script>
    <script src="<?php echo e(asset('panel/app-assets/vendors/js/pickers/pickadate/picker.time.js')); ?>"></script>
    <script src="<?php echo e(asset('panel/app-assets/vendors/js/pickers/pickadate/legacy.js')); ?>"></script>
    <script src="<?php echo e(asset('panel/app-assets/vendors/js/pickers/flatpickr/flatpickr.min.js')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('panel/app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('panel/app-assets/js/core/app.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('panel/app-assets/js/scripts/forms/pickers/form-pickers.js')); ?>"></script>
    <!-- END: Page JS-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/coupons/edit.blade.php ENDPATH**/ ?>