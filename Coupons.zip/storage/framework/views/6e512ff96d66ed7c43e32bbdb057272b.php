<div class="row">
    <?php if($showSuccess): ?>
        <div class="alert alert-success" role="alert">
            <h4 class="alert-heading"><?php echo e(__('Success')); ?></h4>
            <div class="alert-body">
                <?php echo e(__('Logo added successfully')); ?>

            </div>
        </div>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginala762cc5f3a3d9d75447d6bee74b86357 = $component; } ?>
<?php $component = App\View\Components\Form\SingleImage::resolve(['name' => 'image','label' => 'Logo'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.single-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Form\SingleImage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['mode' => 'image']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala762cc5f3a3d9d75447d6bee74b86357)): ?>
<?php $component = $__componentOriginala762cc5f3a3d9d75447d6bee74b86357; ?>
<?php unset($__componentOriginala762cc5f3a3d9d75447d6bee74b86357); ?>
<?php endif; ?>

    <div class="col-lg-6 col-md-12 mb-1 mb-sm-0 py-1">
        <label for="color" class="form-label"><?php echo e(__('Primary Color')); ?></label>
        <input type="color" id="color" wire:model="color" class="form-control" style="height: 40px;">
    </div>

    <div>
        <div class="form-check col-lg-6 col-md-12 mb-1 mb-sm-0 py-1">
            <input class="form-check-input" wire:model="is_shown" type="checkbox" id="is_shown">
            <label class="form-check-label" for="is_shown"> <?php echo e(__('Show Languages Items?')); ?> </label>
        </div>
        <?php $__errorArgs = ['is_shown'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: red;">
                <?php echo e($message); ?>

            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <div class="form-check col-lg-6 col-md-12 mb-1 mb-sm-0 py-1">
            <input class="form-check-input" wire:model="show_store_items" type="checkbox" id="show_store_items">
            <label class="form-check-label" for="show_store_items"> <?php echo e(__('Show stores items.')); ?> </label>
        </div>
        <?php $__errorArgs = ['show_store_items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: red;">
                <?php echo e($message); ?>

            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <?php if (isset($component)) { $__componentOriginal8659fc05c608cfcd9dd7d6dd2434908e = $component; } ?>
<?php $component = App\View\Components\Form\Submit::resolve(['text' => 'Store','action' => 'store()','type' => 'button'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.submit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Form\Submit::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8659fc05c608cfcd9dd7d6dd2434908e)): ?>
<?php $component = $__componentOriginal8659fc05c608cfcd9dd7d6dd2434908e; ?>
<?php unset($__componentOriginal8659fc05c608cfcd9dd7d6dd2434908e); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/livewire/backend/website-settings/setup-logo.blade.php ENDPATH**/ ?>