<?php $__env->startSection('title', __('Setup Website Logo')); ?>
<?php $__env->startSection('page-index', __('Website')); ?>
<?php $__env->startSection('root', __('Setup')); ?>
<?php $__env->startSection('sub-root', __('CM')); ?>


<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.css"
        integrity="sha512-3UMpdtCnKd9XmeFHsBFV7Ux64O/+uV7K8pKdGRzLgoftghLGUuV6U2G6UjxP0TpHbKnK2O/8i/61bnN5ElC+w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Setup the logo')); ?></h4>
                    </div>
                    <div class="card-body">

                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.website-settings.setup-logo', [])->html();
} elseif ($_instance->childHasBeenRendered('DjuJEmo')) {
    $componentId = $_instance->getRenderedChildComponentId('DjuJEmo');
    $componentTag = $_instance->getRenderedChildComponentTagName('DjuJEmo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DjuJEmo');
} else {
    $response = \Livewire\Livewire::mount('backend.website-settings.setup-logo', []);
    $html = $response->html();
    $_instance->logRenderedChild('DjuJEmo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.js"
        integrity="sha512-X3q3tFpHtS0S8vjZdL1z2tRJ4R4lX96f4lMpP+DxLnI+WsLKml8GwvMh5uk5ivz+5B60E8Bv96gz+7N13L1bdw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(document).ready(function() {
            $("#color-picker").spectrum({
                showInput: true,
                preferredFormat: "hex",
                showAlpha: false
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/settings/logo-setup.blade.php ENDPATH**/ ?>