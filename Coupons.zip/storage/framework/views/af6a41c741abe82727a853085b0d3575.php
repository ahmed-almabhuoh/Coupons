<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Css File -->
    <?php if(session('lang') == 'ar'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('front/client/css/master-rtl.css')); ?>" />
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('front/client/css/master.css')); ?>" />
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('front/client/css/bootstrap.min.css')); ?>" />
    <!-- Bootstrap File -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('front/client/css/all.min.css')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <!-- Page title -->
    <title><?php echo e(__('Home')); ?></title>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>


    <!-- ================Start Header============== -->
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <div class="logo">
                <?php
                    $logo = DB::table('website_settings')
                        ->orderByDESC('created_at')
                        ->first()->logo;
                ?>
                <img src="<?php echo e(env('APP_URL') . 'content/' . $logo); ?>" alt="" style="width: 50px; height: 50px;"
                    class="website-logo">
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main"
                aria-controls="main" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="main">

                
                <?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
        <!-- End Container -->
    </nav>
    <!-- End Nav -->
    <!-- ================ End Header ================= -->


    <!-- ================Start Hero Section=========== -->
    <div id="carouselExampleControls" class="carousel slide mb-0" data-bs-ride="carousel">
        <div class="carousel-inner">
            

            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($offer->btn_action); ?>">
                    <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                        <div class="image-container">
                            <img src="<?php echo e(env('APP_URL') . 'content/' . $offer->image); ?>" class="d-block  "
                                alt="...">
                        </div>
                        <div class="carousel-caption">
                            <a class="dif-button btn btn-primary"
                                href="<?php echo e($offer->btn_action); ?>"><?php echo e($offer->btn_txt); ?></a>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?php echo e(__('Previous')); ?></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?php echo e(__('Next')); ?></span>
        </button>
    </div>
    <!-- =============== End Hero Section ============ -->

    <!-- ============== Start Main Section ========== -->
    <div class=" pt-5 pb-5">
        <div class="container">


            <?php if(count($products) >= 1): ?>
                <div class="row">
                    <section class="portfolio special-offers" id="Portfolio">
                        <div class="container">
                            <!-- Head Text -->
                            <div
                                class="main-title fw-bold fs-2 d-flex justify-content-center text-center mb-5 position-relative ">
                                <h2 class="position-absolute "> <?php echo e(__('Special Offers')); ?></h2>
                            </div>
                            <!-- Cards -->
                            <!-- Card 1 -->
                            <div class="portfolio-gallery offers ">
                                <!-- Card 1 -->
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item">
                                        <div class="card inner special-offers">
                                            <!-- icon -->
                                            <div class="img-top">
                                                <?php if($product->image): ?>
                                                    <img src="<?php echo e(env('APP_URL') . 'content/' . $product->image); ?>"
                                                        class="card-img-top" alt="...">
                                                <?php else: ?>
                                                    <img src="<?php echo e(env('APP_URL') . 'content/products/default.jpg'); ?>"
                                                        class="card-img-top" alt="...">
                                                <?php endif; ?>
                                                <img src="<?php echo e(env('APP_URL') . 'content/' . $product->image ?? 'default.jpg'); ?>"
                                                    class="card-img-top" alt="...">
                                            </div>
                                            <!-- img -->
                                            <div class="img icons">
                                                <img src="<?php echo e(env('APP_URL') . 'content/' . $product->store->icon); ?>"
                                                    alt="portfolio" style="width: 50px; height: 50px;">
                                            </div>
                                            <!-- text -->
                                            <div class="body">
                                                <p><?php echo e($product->store->name); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>


                    </section>
                </div>
            <?php endif; ?>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.client.home', ['coupons' => $coupons,'stores' => $stores,'categories' => $categories])->html();
} elseif ($_instance->childHasBeenRendered('GpImonn')) {
    $componentId = $_instance->getRenderedChildComponentId('GpImonn');
    $componentTag = $_instance->getRenderedChildComponentTagName('GpImonn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GpImonn');
} else {
    $response = \Livewire\Livewire::mount('front.client.home', ['coupons' => $coupons,'stores' => $stores,'categories' => $categories]);
    $html = $response->html();
    $_instance->logRenderedChild('GpImonn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>
        </section>
    </div>
    <!-- ============== End Main Section =========== -->


    <!--=============== Start Footer =============== -->
    <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=============== End Footer =========== -->

    <script src="<?php echo e(asset('front/client/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front/client/js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front/client/js/script.js')); ?>"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/client/home.blade.php ENDPATH**/ ?>