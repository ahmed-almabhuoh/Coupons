<?php
    $site = DB::table('website_settings')->first();
?>

<?php if($site->lang_is_shown): ?>
    <nav class="header">
        <div class="language-switcher">
            <ul>
                <li><a href="<?php echo e(route('admins.change.locale', 'en')); ?>"
                        class="<?php echo e(session('lang') == 'en' ? 'active' : ''); ?>"><?php echo e(__('English')); ?></a></li>
                <li><a href="<?php echo e(route('admins.change.locale', 'en')); ?>"
                        class="<?php echo e(session('lang') == 'ar' ? 'active' : ''); ?>"><?php echo e(__('Arabic')); ?></a></li>
            </ul>
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/partials/lang-switcher.blade.php ENDPATH**/ ?>