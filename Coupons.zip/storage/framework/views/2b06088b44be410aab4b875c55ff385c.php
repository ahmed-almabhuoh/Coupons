<div class="card-wrapper">
    <!-- Add Image -->
    <div>
        <label for="imageUpload" class="custom-file-upload" style="background-image: ;">

        </label>
        <input type="file" id="imageUpload" wire:model="image">
        <div id="imagePreview"></div>
    </div>
    <!--Start Card -->
    <div class="card-body">
        <form method="POST">
            <div class="form-group">
                <div class="first-last">
                    <label for="fullname"> <?php echo e(__('Full Name')); ?> </label>
                    <input type="text" class="first form-control" wire:model="fullname" name="name" required
                        autofocus>
                    <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red;">
                            <?php echo e($message); ?>

                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label for="email"> <?php echo e(__('E-Mail Address')); ?> </label>
                <input id="email" type="email" wire:model="email" class="form-control" name="email" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color: red;">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="phone"> <?php echo e(__('Phone Number')); ?> </label>
                <input id="phone" type="tel" class="form-control" wire:model="phone" name="phone" required
                    value="966 |">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color: red;">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <!-- Switch -->
            <div class="form-check form-switch">
                <label class="form-check-label" for="flexSwitchCheckDefault"> <?php echo e(__('Notification')); ?> </label>
                <input class="form-check-input" type="checkbox" wire:model="notification" role="switch"
                    id="flexSwitchCheckDefault">
                <?php $__errorArgs = ['notification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color: red;">
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group no-margin">
                <button type="button" wire:click="updateAccount()" class="btn btn-primary btn-block">
                    <?php echo e(__('Save Edit')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/livewire/front/auth/manage-account.blade.php ENDPATH**/ ?>