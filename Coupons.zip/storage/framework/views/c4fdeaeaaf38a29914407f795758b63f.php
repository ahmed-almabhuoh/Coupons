<div class="container">
    <div class="row">
        <div class="main-title fw-bold fs-2 d-flex justify-content-center text-center mb-5 position-relative ">
            <h2 class="position-absolute "> <?php echo e(__('Blog')); ?> </h2>
        </div>
    </div>
    <div class="row">

        <?php if($new_website_settings->show_store_items): ?>
            <div class="dropdown" wire:ignore>
                <a class="btn  dropdown-toggle blog" href="#" role="button" id="dropdownMenuLink"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo e(__('All')); ?>

                </a>

                <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li wire:click="dropForStores('<?php echo e($store->id); ?>')"><a class="dropdown-item text-black-50"
                                href="#"><?php echo e($store->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="filter-buttons">
            <ul id="filter-btns">
                <li class="<?php echo e($selectedCategory == 'all' ? 'active' : ''); ?>" data-target="all" wire:click="selectByCAT">
                    <?php echo e(__('All')); ?>

                </li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="<?php echo e($selectedCategory == $category->id ? 'active' : ''); ?>"
                        wire:click="selectByCAT('<?php echo e($category->id); ?>')">
                        <img class="img-product" src="<?php echo e(env('APP_URL') . 'content/' . $category->image); ?>"
                            alt="">
                        <?php echo e($category->name); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>


    </div>
    <div class="row mb-lg-3">
        <!-- =============Start portfolio=========== -->

        <div class="portfolio-gallery offers-product" id="portfolio-gallery">
            <?php if(!count($blogs)): ?>
                <h3><?php echo e(__('No blogs found here!')); ?></h3>
            <?php endif; ?>

            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item" data-id="Fashion">
                    <!-- card #1 -->
                    <div class="card offers-product blog">
                        <a class="category" href="<?php echo e(route('categories.edit', Crypt::encrypt($category->id))); ?>">
                            <?php echo e($blog->category->name); ?> </a>
                        <img class="share-icon" src="<?php echo e(asset('front/client/imgs/share-icon-copuon.png')); ?>"
                            onclick="shareByEmail(<?php echo e($blog); ?>, '<?php echo e(Crypt::encrypt($blog->id)); ?>', '<?php echo e(env('APP_URL') . 'articals/' . Crypt::encrypt($blog->id)); ?>')"
                            alt="">
                        <img src="<?php echo e(env('APP_URL') . 'content/' . $blog->image); ?>" class="card-img-top"
                            alt="...">
                        <div class="card-body">
                            <h6 class="card-title blog"><?php echo e($blog->title); ?></h6>
                            </p>
                        </div>
                        <div class="position-relative">
                            <div class="bottom-text mb-5 d-flex justify-content-around">
                                <button class="button blog btn btn-primary"
                                    onclick="redirectToArticals('<?php echo e(Crypt::encrypt($blog->id)); ?>')"><span
                                        class="m-auto"><?php echo e(__('Git it')); ?></span></button>
                            </div>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- ============================================= -->
            <!-- =============Start portfolio=========== -->
        </div>

    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Share Button
        function shareByEmail(blog, enc_blog_id, url) {
            const subject = blog.title;
            const body =
                `مرحبًا،\n\nأردت مشاركة هذا المنشور المدوّن معك من ${blog.title}: \n\n ${url}\n\nتفضل بزيارة هذا الرابط لقراءة المدونة. \n\nشكرًا لك!`;

            const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
            window.location.href = mailtoUrl;
        }
    </script>
    <script>
        function redirectToArticals($url) {
            window.location.href = '/articals/' + $url;
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/livewire/front/client/blogs.blade.php ENDPATH**/ ?>