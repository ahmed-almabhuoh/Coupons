<div class="card-datatable table-responsive pt-0">
    <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer">
        <div class="d-flex justify-content-between align-items-center header-actions mx-1 row mt-75">
            <div class="col-sm-12 col-md-4 col-lg-6">
                <div class="dataTables_length" id="DataTables_Table_0_length"><label><?php echo e(__('Show')); ?> <select
                            wire:model="paginate" name="DataTables_Table_0_length" aria-controls="DataTables_Table_0"
                            class="form-select">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select> <?php echo e(__('entries')); ?></label></div>
            </div>
            <div class="col-sm-12 col-md-8 col-lg-6 ps-xl-75 ps-0">
                <div
                    class="dt-action-buttons text-xl-end text-lg-start text-md-end text-start d-flex align-items-center justify-content-md-end align-items-center flex-sm-nowrap flex-wrap me-1">
                    <div class="me-1">
                        <div id="DataTables_Table_0_filter" class="dataTables_filter"><label> <?php echo e(__('Search')); ?> <input
                                    type="search" class="form-control" placeholder="" wire:model="searchTerm"
                                    aria-controls="DataTables_Table_0"></label></div>
                    </div>
                    <div class="dt-buttons btn-group flex-wrap">
                        <a href="<?php echo e(route('offers.create')); ?>" class="btn add-new btn-primary mt-50">
                            <span><?php echo e(__('Add New Offer')); ?></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <table class="coupon-list-table table dataTable no-footer dtr-column" id="DataTables_Table_0" role="grid"
            aria-describedby="DataTables_Table_0_info">
            <thead class="table-light">
                <tr role="row">
                    <th class="control sorting_disabled" rowspan="1" colspan="1"
                        style="width: 31.6562px; display: none;" aria-label=""></th>
                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1"
                        style="width: 101.734px;" aria-label="Role: activate to sort column ascending">
                        <?php echo e(__('Image')); ?></th>
                    
                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1"
                        style="width: 101.266px;" aria-label="Coupon: activate to sort column ascending">
                        <?php echo e(__('Action')); ?></th>
                    <?php if(auth()->user()->can('delete-offer') ||
                            auth()->user()->can('edit-offer')): ?>
                        <th class="sorting_disabled" rowspan="1" colspan="1" style="width: 135.891px;"
                            aria-label="Actions"> <?php echo e(__('Actions')); ?> </th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if(!count($offers)): ?>
                    <tr class="odd">
                        <td valign="top" colspan="6" class="dataTables_empty">
                            <?php echo e(__('No offers found yet ... !')); ?> </td>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if($offer->image): ?>
                                <span class="avatar"><img class="round"
                                        src="<?php echo e(env('APP_URL') . 'content/' . $offer->image); ?>" alt="avatar"
                                        height="40" width="40">
                                </span>
                            <?php else: ?>
                                <?php echo e(__('No image')); ?>

                            <?php endif; ?>
                        </td>
                        
                        <td>
                            <?php if($offer->btn_txt): ?>
                                <a href="<?php echo e($offer->btn_action); ?>" target="_blank"
                                    class="btn btn-relief-info"><?php echo e($offer->btn_txt); ?></a>
                            <?php endif; ?>
                        </td>
                        <?php if(auth()->user()->can('delete-offer') ||
                                auth()->user()->can('edit-offer')): ?>
                            <td>

                                <?php if(auth()->user()->can('edit-offer')): ?>
                                    <a href="<?php echo e(route('offers.edit', Crypt::encrypt($offer->id))); ?>"
                                        class="btn btn-icon btn-info waves-effect waves-float waves-light">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-inbox">
                                            
                                            <path
                                                d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10h-2c0 4.411-3.589 8-8 8s-8-3.589-8-8 3.589-8 8-8c2.394 0 4.561.988 6.129 2.571l-2.058 2.058h5.929v-5.929l-2.057 2.057c-1.323-1.323-3.058-2.057-4.872-2.057zm5.5 5.5l-2.5 2.5v-7h-1v7l-2.5-2.5-1.414 1.414 4.914 4.914 4.914-4.914-1.414-1.414z">
                                            </path>
                                        </svg>
                                    </a>
                                <?php endif; ?>

                                <?php if(auth()->user()->can('delete-offer')): ?>
                                    <button type="button"
                                        onclick="confirmationDelete('<?php echo e(Crypt::encrypt($offer->id)); ?>', this, '<?php echo e(auth('admin')->user()->lang); ?>')"
                                        class="btn btn-icon btn-danger waves-effect waves-float waves-light">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-inbox">
                                            
                                            <path
                                                d="M19 5h-3.5l-1-1h-5l-1 1H5v2h14V5zM8.5 8l-1.5 9h9l-1.5-9h-6zM10 18v-7h1v7h-1zm3 0v-7h1v7h-1zm3 0v-7h1v7h-1z">
                                            </path>
                                        </svg>
                                    </button>
                                <?php endif; ?>

                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd" wire:loading>
                    <td valign="top" colspan="6" class="dataTables_empty">
                        <?php echo e(__('Searching about offers ...')); ?>

                    </td>
                </tr>
            </tbody>
        </table>
        <div class="d-flex justify-content-between mx-2 row mb-1">
            <?php echo e($offers->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/livewire/backend/offers/offer-search.blade.php ENDPATH**/ ?>