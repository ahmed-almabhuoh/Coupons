<?php $__env->startSection('title', __('Create a new FQs')); ?>
<?php $__env->startSection('page-index', __('FQs')); ?>
<?php $__env->startSection('root', __('Create')); ?>
<?php $__env->startSection('sub-root', __('CM')); ?>


<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Create a new FQs')); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.aqs.create', [])->html();
} elseif ($_instance->childHasBeenRendered('m9CB5u2')) {
    $componentId = $_instance->getRenderedChildComponentId('m9CB5u2');
    $componentTag = $_instance->getRenderedChildComponentTagName('m9CB5u2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('m9CB5u2');
} else {
    $response = \Livewire\Livewire::mount('backend.aqs.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('m9CB5u2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('category-created', function(data) {
                // alert(data.message);
                console.log('Here');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/aqs/store.blade.php ENDPATH**/ ?>