<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-start d-block d-md-inline-block mt-25"><?php echo e(__('COPYRIGHT')); ?> &copy;
            <?php echo e(Date::now()->year); ?><a class="ms-25" href="<?php echo e(env('APP_URL')); ?>"
                target="_blank"><?php echo e(__(env('APP_NAME'))); ?></a><span class="d-none d-sm-inline-block">,
                <?php echo e(__('All rights Reserved')); ?></span></span><span
            class="float-md-end d-none d-md-block"><?php echo e(__(env('APP_NAME'))); ?> <?php echo e(__('& Made with')); ?><i
                data-feather="heart"></i></span></p>
</footer>
<?php /**PATH C:\wamp64\www\Coupons\resources\views////partials/footer.blade.php ENDPATH**/ ?>