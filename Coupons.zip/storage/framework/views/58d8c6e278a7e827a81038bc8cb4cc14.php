<?php $__env->startSection('title', __('Favorite')); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .red-text {
            color: red;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-tabel">
        <div class="header-text">
            <h3><?php echo e(__('Coupons')); ?></h3>
            <p><?php echo e(__('Coupons that you have obtained through us or that you have posted we\'ve got')); ?></p>
        </div>
        <!-- Start Tabel -->
        <div class="container">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.auth.favorite', [])->html();
} elseif ($_instance->childHasBeenRendered('gBBfK2j')) {
    $componentId = $_instance->getRenderedChildComponentId('gBBfK2j');
    $componentTag = $_instance->getRenderedChildComponentTagName('gBBfK2j');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gBBfK2j');
} else {
    $response = \Livewire\Livewire::mount('front.auth.favorite', []);
    $html = $response->html();
    $_instance->logRenderedChild('gBBfK2j', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <!-- End Tabel -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.client-pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/pages/favorite.blade.php ENDPATH**/ ?>