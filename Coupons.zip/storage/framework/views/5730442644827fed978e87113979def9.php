<div class="col-lg-6 col-md-12 mb-1 mb-sm-0 py-1">
    <label for="<?php echo e($id ?? $name); ?>" class="form-label"><?php echo e(__($label)); ?></label>
    <input class="form-control" type="file" id="<?php echo e($id ?? $name); ?>" wire:model="<?php echo e($model ?? $name); ?>" multiple>
</div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/components/form/multi-image.blade.php ENDPATH**/ ?>