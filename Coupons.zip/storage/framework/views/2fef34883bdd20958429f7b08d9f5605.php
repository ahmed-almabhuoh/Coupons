<div class="col-lg-6 col-md-12 mb-1 mb-sm-0 py-1">
    <label for="<?php echo e($id ?? $name); ?>" class="form-label"><?php echo e(__($label)); ?></label>
    <input class="form-control <?php $__errorArgs = [$model ?? $name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="<?php echo e($id ?? $name); ?>"
        wire:model="<?php echo e($model ?? $name); ?>">
    <?php if($description ?? false): ?>
        <small><?php echo e(__($description)); ?></small>
    <?php endif; ?>
    <?php $__errorArgs = [$model ?? $name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e(__($message)); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/components/form/single-image.blade.php ENDPATH**/ ?>