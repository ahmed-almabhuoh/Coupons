

<?php $__env->startSection('title', __('Change Password')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="chang-password">
        <div class="header-text">
            <h3><?php echo e(__('Change Password')); ?></h3>
            <p><?php echo e(__('Re-change your password when you feel someone has access to your account')); ?></p>
        </div>

        <div class="card-wrapper">

            <input type="file" id="imageUpload">
            <div id="imagePreview"></div>
            <!--Start Card -->
            <div class="card-body">
                <!-- here Error on eye -->


                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.auth.change-password', [])->html();
} elseif ($_instance->childHasBeenRendered('uZwpNP7')) {
    $componentId = $_instance->getRenderedChildComponentId('uZwpNP7');
    $componentTag = $_instance->getRenderedChildComponentTagName('uZwpNP7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uZwpNP7');
} else {
    $response = \Livewire\Livewire::mount('front.auth.change-password', []);
    $html = $response->html();
    $_instance->logRenderedChild('uZwpNP7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.client-pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/auth/change-password.blade.php ENDPATH**/ ?>