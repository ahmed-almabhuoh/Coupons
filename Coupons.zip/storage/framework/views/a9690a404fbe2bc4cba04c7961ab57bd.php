<?php $__env->startSection('title', __('Control Panel')); ?>
<?php $__env->startSection('page-index', __('Dashboard')); ?>
<?php $__env->startSection('root', __('Panel')); ?>
<?php $__env->startSection('sub-root', __('Manager')); ?>


<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/temp/app.blade.php ENDPATH**/ ?>