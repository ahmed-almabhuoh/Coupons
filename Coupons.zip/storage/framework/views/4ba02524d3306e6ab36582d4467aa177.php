<?php $__env->startSection('title', __('Manage Account')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header-text">
        <h3><?php echo e(__('Edit account information')); ?></h3>
        <p> <?php echo e(__('You can modify the account information once and you will need 60 days before you can edit again')); ?> </p>
    </div>


    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.auth.manage-account', [])->html();
} elseif ($_instance->childHasBeenRendered('0Bk9gKq')) {
    $componentId = $_instance->getRenderedChildComponentId('0Bk9gKq');
    $componentTag = $_instance->getRenderedChildComponentTagName('0Bk9gKq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0Bk9gKq');
} else {
    $response = \Livewire\Livewire::mount('front.auth.manage-account', []);
    $html = $response->html();
    $_instance->logRenderedChild('0Bk9gKq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.client-pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/pages/account.blade.php ENDPATH**/ ?>