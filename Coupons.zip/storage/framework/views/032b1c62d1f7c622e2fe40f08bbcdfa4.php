﻿<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/authorization/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- FontAwsome -->
    <link rel="stylesheet" href="<?php echo e(asset('front/authorization/css/all.min.css')); ?>">
    <!-- Css File -->
    <?php if(session('lang') == 'en'): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/authorization/css/master.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/authorization/css/master-rtl.css')); ?>">
    <?php endif; ?>
    <!-- page Title -->
    <title> <?php echo e(__('Register a new account')); ?> </title>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<!-- ================================================================= -->
<!-- Start Heaer -->
<?php echo $__env->make('frontend.partials.lang-switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Heaer -->

<body class="my-login-page">
    <!-- <img class="background" src="./img/line-in-background.png" alt=""> -->

    <section class="h-100">
        <div class="container h-100">
            <div class="row justify-content-md-center h-100">
                <div class="card-wrapper">

                    <div class="card fat register">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e(__('Register')); ?></h4>

                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.auth.register', [])->html();
} elseif ($_instance->childHasBeenRendered('pVK3spI')) {
    $componentId = $_instance->getRenderedChildComponentId('pVK3spI');
    $componentTag = $_instance->getRenderedChildComponentTagName('pVK3spI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pVK3spI');
} else {
    $response = \Livewire\Livewire::mount('front.auth.register', []);
    $html = $response->html();
    $_instance->logRenderedChild('pVK3spI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- JS File -->
    <script src="<?php echo e(asset('front/authorization/js/script.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/auth/register.blade.php ENDPATH**/ ?>