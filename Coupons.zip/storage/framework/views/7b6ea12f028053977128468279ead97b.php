  <div class="col-lg-6 col-md-12 mb-1 mb-sm-0 py-1">
      <label class="form-label" for="<?php echo e($id ?? $name); ?>"><?php echo e(__($label)); ?></label>
      <select class="form-select <?php $__errorArgs = [$model ?? $name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      is-invalid
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="<?php echo e($model ?? $name); ?>"
          name="<?php echo e($name); ?>" id="<?php echo e($id ?? $name); ?>">
          <option><?php echo e(__('-- Choose an option --')); ?></option>
          <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e(is_string($option) ? $option : $option->id); ?>">
                  <?php echo e(is_string($option) ? __(ucfirst($option)) : $option->name ?? $option->code ?? $option->title ?? $option->id); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = [$model ?? $name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e(__($message)); ?>

          </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/components/form/select.blade.php ENDPATH**/ ?>