

<?php $__env->startSection('title', __('Update') . ' ' . $admin->full_name); ?>
<?php $__env->startSection('page-index', __('Admins')); ?>
<?php $__env->startSection('root', __('Update')); ?>
<?php $__env->startSection('sub-root', __('HR')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Update') . ' '. $admin->full_name); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.admins.update', ['admin' => $admin])->html();
} elseif ($_instance->childHasBeenRendered('i2ROOyI')) {
    $componentId = $_instance->getRenderedChildComponentId('i2ROOyI');
    $componentTag = $_instance->getRenderedChildComponentTagName('i2ROOyI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('i2ROOyI');
} else {
    $response = \Livewire\Livewire::mount('backend.admins.update', ['admin' => $admin]);
    $html = $response->html();
    $_instance->logRenderedChild('i2ROOyI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/admins/edit.blade.php ENDPATH**/ ?>