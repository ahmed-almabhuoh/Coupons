<?php $__env->startSection('title', 'Update <?php echo e($admin->full_name); ?>'); ?>
<?php $__env->startSection('page-index', 'Admins'); ?>
<?php $__env->startSection('root', 'Update'); ?>
<?php $__env->startSection('sub-root', 'HR'); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Update ') . $admin->full_name); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.admins.update', ['admin' => $admin])->html();
} elseif ($_instance->childHasBeenRendered('qPGKrOE')) {
    $componentId = $_instance->getRenderedChildComponentId('qPGKrOE');
    $componentTag = $_instance->getRenderedChildComponentTagName('qPGKrOE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qPGKrOE');
} else {
    $response = \Livewire\Livewire::mount('backend.admins.update', ['admin' => $admin]);
    $html = $response->html();
    $_instance->logRenderedChild('qPGKrOE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/admins/edit.blade.php ENDPATH**/ ?>