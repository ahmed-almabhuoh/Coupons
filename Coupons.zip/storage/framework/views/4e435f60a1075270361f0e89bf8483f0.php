<style>
    li {
        font-family: 'Cairo', sans-serif !important;
    }
</style>





<?php if(auth()->user()->can('view-admins') ||
        auth()->user()->can('create-admin') ||
        auth()->user()->can('view-users') ||
        auth()->user()->can('create-users')): ?>
    <li class=" navigation-header"><span data-i18n="Apps &amp; Pages"><?php echo e(__('Human Resources')); ?></span><svg
            xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
            class="feather feather-more-horizontal">
            <circle cx="12" cy="12" r="1"></circle>
            <circle cx="19" cy="12" r="1"></circle>
            <circle cx="5" cy="12" r="1"></circle>
        </svg>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-admins') ||
        auth()->user()->can('create-admin')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="shield"></i><span
                class="menu-title text-truncate" data-i18n="Invoice"><?php echo e(__('Admins')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-admins')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('admins.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-admin')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('admins.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-users') ||
        auth()->user()->can('create-user')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="user"></i><span
                class="menu-title text-truncate" data-i18n="Invoice"><?php echo e(__('Users')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-users')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('users.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-user')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('users.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>


<?php if(auth()->user()->can('view-categories') ||
        auth()->user()->can('create-category') ||
        auth()->user()->can('view-users') ||
        auth()->user()->can('create-users')): ?>
    <li class=" navigation-header"><span data-i18n="Apps &amp; Pages"><?php echo e(__('Content Management')); ?></span><svg
            xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
            class="feather feather-more-horizontal">
            <circle cx="12" cy="12" r="1"></circle>
            <circle cx="19" cy="12" r="1"></circle>
            <circle cx="5" cy="12" r="1"></circle>
        </svg>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-categories') ||
        auth()->user()->can('create-category') ||
        auth()->user()->can('view-stores') ||
        auth()->user()->can('create-store') ||
        auth()->user()->can('view-coupons') ||
        auth()->user()->can('create-coupon') ||
        auth()->user()->can('view-products') ||
        auth()->user()->can('create-product')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="list"></i><span
                class="menu-title text-truncate" data-i18n="Invoice"><?php echo e(__('Categories')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-categories')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('categories.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-category')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('categories.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-countries') ||
        auth()->user()->can('create-country')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="globe"></i><span
                class="menu-title text-truncate" data-i18n="Invoice"><?php echo e(__('Countries')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-countries')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('countries.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-country')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('countries.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-stores') ||
        auth()->user()->can('create-store')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                data-feather="shopping-bag"></i><span class="menu-title text-truncate"
                data-i18n="Invoice"><?php echo e(__('Stores')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-stores')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('stores.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-store')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('stores.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-coupons') ||
        auth()->user()->can('create-coupon')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="tag"></i><span
                class="menu-title text-truncate" data-i18n="Invoice"><?php echo e(__('Coupons')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-coupons')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('coupons.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-coupon')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('coupons.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-products') ||
        auth()->user()->can('create-product')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="package"></i><span
                class="menu-title text-truncate" data-i18n="Invoice"><?php echo e(__('Products')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-products')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('products.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-product')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('products.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-A&Qs') ||
        auth()->user()->can('create-A&Q')): ?>
    <li class=" navigation-header"><span data-i18n="Apps &amp; Pages"><?php echo e(__('Site Settings')); ?></span><svg
            xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
            class="feather feather-more-horizontal">
            <circle cx="12" cy="12" r="1"></circle>
            <circle cx="19" cy="12" r="1"></circle>
            <circle cx="5" cy="12" r="1"></circle>
        </svg>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-A&Qs') ||
        auth()->user()->can('create-A&Q') ||
        auth()->user()->can('view-offers') ||
        auth()->user()->can('create-offer') ||
        auth()->user()->can('view-blogs') ||
        auth()->user()->can('create-blog')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                data-feather="help-circle"></i><span class="menu-title text-truncate"
                data-i18n="Invoice"><?php echo e(__('FQs')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-A&Qs')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('aqs.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-A&Q')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('aqs.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-offers') ||
        auth()->user()->can('create-offer')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                data-feather="play-circle"></i><span class="menu-title text-truncate"
                data-i18n="Invoice"><?php echo e(__('Offers')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-offers')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('offers.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-offer')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('offers.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('view-serials') ||
        auth()->user()->can('create-serial')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="tag"></i><span
                class="menu-title text-truncate" data-i18n="Invoice"><?php echo e(__('Licenses')); ?></span></a>
        <ul class="menu-content">
            <?php if(auth()->user()->can('view-serials')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('serials.index')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate"
                            data-i18n="List"><?php echo e(__('List')); ?></span></a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('create-serial')): ?>
                <li><a class="d-flex align-items-center" href="<?php echo e(route('serials.create')); ?>"><i
                            data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Add">
                            <?php echo e(__('Add')); ?> </span></a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>





<?php if(auth()->user()->can('manage-website')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('logo.setup')); ?>">
            <i data-feather="image"></i>
            <span class="menu-title text-truncate" data-i18n="Chat"><?php echo e(__('Setup Website')); ?></span>
        </a>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('assign-permissions') ||
        auth()->user()->can('create-role') ||
        auth()->user()->can('view-roles') ||
        auth()->user()->can('edit-role') ||
        auth()->user()->can('delete-role')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('roles.management')); ?>">
            <i data-feather="user-check"></i>
            <span class="menu-title text-truncate" data-i18n="Chat"><?php echo e(__('Roles Management')); ?></span>
        </a>
    </li>
<?php endif; ?>

<?php if(auth()->user()->can('contact-us')): ?>
    <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('contacts.index')); ?>">
            <i data-feather="phone"></i>
            <span class="menu-title text-truncate" data-i18n="Chat"><?php echo e(__('Contact Us')); ?></span>
        </a>
    </li>
<?php endif; ?>

<li class=" navigation-header"><span data-i18n="Apps &amp; Pages"><?php echo e(__('Account Settings')); ?></span><svg
        xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
        class="feather feather-more-horizontal">
        <circle cx="12" cy="12" r="1"></circle>
        <circle cx="19" cy="12" r="1"></circle>
        <circle cx="5" cy="12" r="1"></circle>
    </svg>
</li>

<li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('manage.admins.accounts')); ?>">
        <i data-feather="settings"></i>
        <span class="menu-title text-truncate" data-i18n="Chat"><?php echo e(__('Update account')); ?></span></a>
</li>

<li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('manage.admins.password')); ?>">
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
            class="feather feather-message-square">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2">
            </rect>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
        </svg><span class="menu-title text-truncate" data-i18n="Chat"><?php echo e(__('Change password')); ?></span></a>
</li>

<li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('logout')); ?>">
        <i data-feather="log-out"></i>
        <span class="menu-title text-truncate" data-i18n="Chat"><?php echo e(__('Logout')); ?></span>
    </a>
</li>
<?php /**PATH C:\wamp64\www\Coupons\resources\views////partials/nav.blade.php ENDPATH**/ ?>