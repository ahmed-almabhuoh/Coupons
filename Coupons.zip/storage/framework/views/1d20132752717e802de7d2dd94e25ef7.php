<form>

    <?php if($messageStatus == 'error'): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(__($showMessage)); ?>

        </div>
    <?php elseif($messageStatus == 'success'): ?>
        <div class="alert alert-primary" role="alert">
            <?php echo e(__($showMessage)); ?>

        </div>
    <?php endif; ?>

    <div class="form-group">
        <label for="email"> <?php echo e(__('E-Mail Address')); ?> </label>
        <input id="email" type="email" class="form-control" name="email" wire:model="email" value="" required
            style="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        border-color: rgb(230, 22, 22);
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: rgb(230, 22, 22);"><?php echo e(__($message)); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="password">
            <?php echo e(__('Password')); ?>

        </label>
        <input id="password" type="password" class="form-control" name="password" required wire:model="password"
            style="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        border-color: rgb(230, 22, 22);
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-eye>
        <span toggle="#password" class="toggle-password fa fa-fw fa-eye"></span>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: rgb(230, 22, 22);"><?php echo e(__($message)); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group no-margin">
        <button type="button" wire:click="login" class="btn btn-primary btn-block">
            <?php echo e(__('Login')); ?>

        </button>
    </div>

    <div class="text-link  margin-top20 text-center">
        <?php echo e(__('Don\'t have an account?..')); ?> <a href="<?php echo e(route('users.register')); ?>"><?php echo e(__('Create an account!')); ?></a>
    </div>
</form>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/livewire/front/auth/login.blade.php ENDPATH**/ ?>