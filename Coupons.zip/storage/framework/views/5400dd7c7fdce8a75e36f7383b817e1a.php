<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Css File -->
    <?php if(session('lang') == 'ar'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('front/client/css/master-rtl.css')); ?>" />
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('front/client/css/master.css')); ?>" />
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('front/client/css/bootstrap.min.css')); ?>" />
    <!-- Bootstrap File -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('front/client/css/all.min.css')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <!-- Page title -->
    <title> <?php echo e(__('Common questions')); ?> </title>
</head>

<body>
    <!-- ================Start Header============== -->
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <div class="logo">
                <img src="<?php echo e(env('APP_URL') . 'content/' . $logo); ?>" alt="" style="width: 50px; height: 50px;"
                    class="website-logo">
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main"
                aria-controls="main" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="main">

                
                <?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
        <!-- End Container -->
    </nav>
    <!-- End Nav -->
    <!-- ================ End Header ================= -->

    <!-- ============== Start Main Section ======== -->
    <div class="main-section common pt-5 pb-3 mt-5">
        <div class="container">
            <?php if(session('message')): ?>
                <div class="alert <?php if(session('code') == 200): ?> alert-success <?php else: ?> alert-danger <?php endif; ?>"
                    role="alert">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <div class="main-title fw-bold fs-2 d-flex justify-content-center text-center  mb-5 position-relative ">
                <h2 class="position-absolute "> <?php echo e(__('Common Questions')); ?></h2>
            </div>
            <div class="row">
                <div class="col-md-6 px-4">
                    <div class="accordion" id="accordionExample">

                        <?php if(!count($fqs)): ?>
                            <h2><?php echo e(__('No questions published yet!')); ?></h2>
                        <?php endif; ?>
                        <?php $__currentLoopData = $fqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo e($index); ?>">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse<?php echo e($index); ?>" aria-expanded="false"
                                        aria-controls="collapse<?php echo e($index); ?>">
                                        <?php echo e($fq->title); ?>

                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($index); ?>" class="accordion-collapse collapse"
                                    aria-labelledby="heading<?php echo e($index); ?>" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <?php echo e($fq->answer); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>
                </div>

                <div class="form col-md-6 px-4">
                    <div class="row ">
                        <div class="col-md-12">

                            <h3> <?php echo e(__('Do you have a question in your mind?!')); ?> </h3>
                            <p> <?php echo e(__('Ask us and we will respond within 24 hours.')); ?> </p>

                            <form class="common-question" method="POST" action="<?php echo e(route('send.contact')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group ">
                                    <!-- <label for="email">Email address</label> -->
                                    <input type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="email" name="email" placeholder="<?php echo e(__('Your E-mail')); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <!-- <label for="message">Message</label> -->
                                    <textarea
                                        class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="message" name="message" rows="5" placeholder="<?php echo e(__('Your Message Here..')); ?>"></textarea>
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div>
                                    <button type="submit" class="btn btn-primary col-6"><?php echo e(__('Submit')); ?></button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============= End Main Section ========== -->

    <!--=============== Start Footer ============= -->
    <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--=============== End Footer =============== -->
    <script src="<?php echo e(asset('front/client/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front/client/js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front/client/js/script.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/client/fqs.blade.php ENDPATH**/ ?>