<?php $__env->startSection('title', __('Update acccount info')); ?>
<?php $__env->startSection('page-index', __('Accounts')); ?>
<?php $__env->startSection('root', __('Update')); ?>
<?php $__env->startSection('sub-root', __('HR')); ?>


<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Update account info') . ': ' . $user->full_name); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.accounts.update-admin-account', ['user' => $user])->html();
} elseif ($_instance->childHasBeenRendered('SZTMMpn')) {
    $componentId = $_instance->getRenderedChildComponentId('SZTMMpn');
    $componentTag = $_instance->getRenderedChildComponentTagName('SZTMMpn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SZTMMpn');
} else {
    $response = \Livewire\Livewire::mount('backend.accounts.update-admin-account', ['user' => $user]);
    $html = $response->html();
    $_instance->logRenderedChild('SZTMMpn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('admin-created', function(data) {
                // alert(data.message);
                console.log('Here');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/account/update-my-account.blade.php ENDPATH**/ ?>