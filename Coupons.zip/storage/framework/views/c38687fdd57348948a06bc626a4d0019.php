﻿<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/authorization/bootstrap/css/bootstrap.min.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

    <!-- FontAwsome -->
    <link rel="stylesheet" href="<?php echo e(asset('front/authorization/css/all.min.css')); ?>">
    <!-- Css File -->
    <?php if(session('lang') == 'en'): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/authorization/css/master.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/authorization/css/master-rtl.css')); ?>">
    <?php endif; ?>
    <!-- page Title -->
    <title> <?php echo e(__('Coupons Login')); ?> </title>


    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<!-- ================================================================= -->
<!-- Start Heaer -->
<?php echo $__env->make('frontend.partials.lang-switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Heaer -->

<body class="my-login-page ">


    <!-- <img class="background" src="./img/line-in-background.png" alt=""> -->
    <section class="h-100">
        <div class="container h-100">
            <div class="row justify-content-md-center h-100">
                <div class="card-wrapper">



                    <div class="card fat login">

                        <div class="card-body">
                            <?php if(session('status') == 200): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php elseif(session('status') == 400): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>
                            <h4 class="card-title"> <?php echo e(__('Login')); ?> </h4>

                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.auth.login', [])->html();
} elseif ($_instance->childHasBeenRendered('XZj6Di4')) {
    $componentId = $_instance->getRenderedChildComponentId('XZj6Di4');
    $componentTag = $_instance->getRenderedChildComponentTagName('XZj6Di4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XZj6Di4');
} else {
    $response = \Livewire\Livewire::mount('front.auth.login', []);
    $html = $response->html();
    $_instance->logRenderedChild('XZj6Di4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                    <div class="footer">
                        <span> <?php echo e(__('Forgot your password?..')); ?> <a href="<?php echo e(route('clients.forgot.password')); ?>">
                                <?php echo e(__('Recover your password')); ?></a></span>
                    </div>
                </div>
            </div>
    </section>
    <script src="<?php echo e(asset('front/authorization/js/script.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/frontend/auth/login.blade.php ENDPATH**/ ?>