<div class="row">
    <section class="portfolio" id="Portfolio">
        <div class="container">
            <div class="row">
                <div class="main-title fw-bold fs-2 d-flex justify-content-center text-center mb-5 position-relative ">
                    <h2 class="position-absolute "> <?php echo e(__('Offers')); ?> </h2>
                </div>
            </div>
            <div class="row">

                <?php if($new_website_settings->show_store_items): ?>
                    <div class="dropdown">
                        <a class="btn  dropdown-toggle offers" href="#" role="button" id="dropdownMenuLink"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(__('All Stores')); ?>

                        </a>

                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <?php $__currentLoopData = $allStores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a class="dropdown-item text-black-50" href="#"
                                        wire:click="getStores('<?php echo e(Crypt::encrypt($store->id)); ?>')"><?php echo e($store->name); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>


                <div class="filter-buttons">
                    <ul id="filter-btns">
                        <li class="<?php echo e($newSelectedCategory == 'all' ? 'active' : ''); ?>" wire:click="getCategories"
                            data-target="all"> <?php echo e(__('All')); ?> </li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-target="Fashion"
                                class="<?php echo e($newSelectedCategory == $category->id ? 'active' : ''); ?>"
                                wire:click="getCategories('<?php echo e(Crypt::encrypt($category->id)); ?>')">
                                <img class="img-product" src="<?php echo e(env('APP_URL') . 'content/' . $category->image); ?>"
                                    alt="">
                                <?php echo e($category->name); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>


            </div>
            <div class="row mb-lg-3">
                <!-- =============Start portfolio=========== -->
                <div class="portfolio-gallery offers-product" id="portfolio-gallery">
                    <?php if(!count($products)): ?>
                        <h3><?php echo e(__('No products found yet!')); ?></h3>
                    <?php endif; ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item" data-id="Fashion">

                            <div class="card offers-product">
                                <a class="category"
                                    href="<?php echo e(route('categories.edit', Crypt::encrypt($category->id))); ?>">
                                    <?php echo e($product->category->name); ?> </a>
                                <img class="share-icon" src="<?php echo e(asset('front/client/imgs/share-icon-copuon.png')); ?>"
                                    onclick="shareOffer(<?php echo e($product); ?>, '<?php echo e(env('APP_URL') . '/offers'); ?>')"
                                    alt="">
                                <?php if($product->image): ?>
                                    <img src="<?php echo e(env('APP_URL') . 'content/' . $product->image); ?>" class="card-img-top"
                                        alt="...">
                                <?php else: ?>
                                    <img src="<?php echo e(env('APP_URL') . 'content/' . $product->store->icon); ?>"
                                        class="card-img-top" alt="...">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                    <p class="card-text"><?php echo e($product->price); ?> <?php echo e(__('Riyals')); ?> <br> <small
                                            class="text-muted"><?php echo e($product->original_price); ?>

                                            <?php echo e(__('Riyals')); ?></small>
                                    </p>
                                </div>
                                <div class="position-relative">
                                    <div class="bottom-text mb-5 d-flex justify-content-around">
                                        <div class="left-sec"> <img class="card-icon"
                                                src="<?php echo e(env('APP_URL') . 'content/' . $product->store->icon); ?>"
                                                alt="">
                                            <span><?php echo e($product->store->name); ?></span>
                                        </div>
                                        <button class="button btn btn-primary"
                                            onclick="getProduct('<?php echo e($product->id); ?>')" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal">
                                            <span class="m-auto"><?php echo e(__('Git it')); ?></span>
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- ============================================= -->

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title m-auto text-black-50 " id="exampleModalLabel">
                                        <?php echo e(__('Product details')); ?></h2>
                                </div>


                                <div class="modal-body ">
                                    <div class="first-sec d-flex justify-content-between">
                                        <!--Section #1 -->
                                        <div class="content d-flex align-items-center justify-content-center">
                                            <img class="icon-model website-logo"
                                                src="<?php echo e(asset('front/client/imgs/flaword-icon-card.png')); ?>"
                                                alt="">
                                            <div class="text-des ml-3">
                                                <strong id="product_store_name"></strong>
                                                <p id="product_description"></p>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <!--Section #2 -->
                                    <div class="midel-sec offers-card d-flex flex-wrap">
                                        <div class="first-dev">

                                            <span><?php echo e(__('Discount')); ?>: <strong
                                                    class="product_discount"></strong></span>
                                        </div>
                                        <div class="first-dev">
                                            <span><?php echo e(__('Last use')); ?>: <strong id="product_last_use"></strong></span>
                                        </div>
                                        <div class="first-dev">
                                            <span><?php echo e(__('Category')); ?>: <strong
                                                    id="product_category_name"></strong></span>
                                        </div>
                                    </div>
                                    <!--Section #3 -->
                                    <div class="midel-sec offers-card d-flex  flex-wrap ">
                                        <div class="first-dev">

                                            <span><?php echo e(__('Original price')); ?>: <strong
                                                    id="product_original_price"></strong></span>
                                        </div>
                                        <div class="first-dev">
                                            <span><?php echo e(__('Discount')); ?>:<strong
                                                    class="text-black-50 product_discount"></strong></span>
                                        </div>
                                        <div class="first-dev">
                                            <span><?php echo e(__('Final price')); ?>: <strong id="product_price"></strong></span>
                                        </div>
                                    </div>

                                    <div class="icon-container">
                                        <div class="icon-box" id="shopping_coupon_action">
                                            <img src="<?php echo e(asset('front/client/imgs/cart.png')); ?>" alt=""
                                                data-src="">
                                            <div>
                                                <p><?php echo e(__('shopping')); ?></p>
                                            </div>
                                        </div>
                                        <div class="icon-box">
                                            <img src="<?php echo e(asset('front/client/imgs/Heart, Favorite.png')); ?>"
                                                alt="" id="favorite_icon"
                                                data-src="<?php echo e(asset('front/client/imgs/heart-selceted.png')); ?>">
                                            <div>
                                                <p><?php echo e(__('favourite')); ?></p>
                                            </div>
                                        </div>
                                        <div class="icon-box">
                                            <img id="product_activation"
                                                src="<?php echo e(asset('front/client/imgs/thumbs-up-like-square.png')); ?>"
                                                alt=""
                                                data-src="<?php echo e(asset('front/client/imgs/lik-selceted.png')); ?>">
                                            <div>
                                                <p><?php echo e(__('active')); ?></p>
                                            </div>
                                        </div>
                                        <div class="icon-box">
                                            <img src="<?php echo e(asset('front/client/imgs/dislike.png')); ?>" alt=""
                                                id="product_inactivation"
                                                data-src="<?php echo e(asset('front/client/imgs/dis-selceted.png')); ?>">
                                            <div>
                                                <p><?php echo e(__('inactive')); ?></p>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="modal-footer d-flex">
                                        <span id="share_element"><img
                                                src="<?php echo e(asset('front/client/imgs/share-icon-copuon.png')); ?>"
                                                alt=""> <?php echo e(__('Share')); ?>

                                        </span>
                                        <a type="button" class="copy-button btn btn-secondary" id="copyButton">
                                            <?php echo e(__('Copy Code')); ?> <img
                                                src="<?php echo e(asset('front/client/imgs/copy-icon.png')); ?>" alt="">
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
                <!-- =============End portfolio=========== -->


            </div>
        </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        async function getProduct(product_id) {
            axios.get('/get-product/' + product_id)
                .then(function(response) {
                    document.getElementById('product_store_name').textContent = response.data.product.store.name;
                    document.getElementById('product_category_name').textContent = response.data.product.category
                        .name;
                    document.getElementById('product_description').textContent = response.data.product.description;
                    document.getElementById('product_original_price').textContent = response.data.product
                        .original_price + ' ريال';
                    document.getElementById('product_price').textContent = response.data.product.price + ' ريال';
                    const elements = document.getElementsByClassName('product_discount');
                    for (let i = 0; i < elements.length; i++) {
                        elements[i].textContent = response.data.product.offer + '%';
                    }

                    if (response.data.product.last_use) {
                        document.getElementById('product_last_use').textContent = timeAgo(response.data.product
                            .last_use);
                    } else {
                        document.getElementById('product_last_use').textContent = 'غير مستخدم';
                    }

                    document.getElementById('product_activation').setAttribute('onclick', 'markAsActivation(' +
                        response.data.product.id + ')');

                    document.getElementById('product_inactivation').setAttribute('onclick', 'markAsInActivation(' +
                        response.data.product.id + ')');

                    const product_action = document.getElementById('product_action');
                    product_action.setAttribute('href', response.data.product.action);

                    var favorite_icon = document.getElementById('favorite_icon');
                    favorite_icon.setAttribute('onclick',
                        'addToFavorite(' + response.data.product.id + ', "product")');

                    // Share Element
                    // product_name, price, discount
                    document.getElementById('share_element').setAttribute('onclick',
                        `shareByEmail('${response.data.product.store.name}', '${response.data.product.original_price} ريال', '${response.data.product.price} ريال')`
                    );

                    // Get the copy button element by ID
                    const copyButton = document.getElementById('copyButton');
                    copyButton.setAttribute('value', response.data.product.name);

                    // Add a click event to the copy button
                    copyButton.onclick = function() {
                        setLastUse(response.data.product.id, 'product');
                        navigator.clipboard.writeText(copyButton.getAttribute('value'));
                        alert('Text copied to clipboard!');
                    };

                    // Shopping Element
                    document.getElementById('shopping_coupon_action').setAttribute('onclick',
                        `redirectShopping('${response.data.product.action}')`);



                    axios.get('/check-user-product/' + product_id)
                        .then(function(response) {
                            if (response.data.has_product) {
                                favorite_icon.setAttribute("src",
                                    "<?php echo e(asset('/front/client/imgs/heart-selceted.png')); ?>");
                                favorite_icon.setAttribute("data-src",
                                    "<?php echo e(asset('/front/client/imgs/Heart, Favorite.png')); ?>");
                            } else {
                                favorite_icon.setAttribute("src",
                                    "<?php echo e(asset('/front/client/imgs/Heart, Favorite.png')); ?>");
                                favorite_icon.setAttribute("data-src",
                                    "<?php echo e(asset('/front/client/imgs/heart-selceted.png')); ?>");
                            }
                        })

                    // console.log(product_store_name);
                })
                .catch(function(error) {
                    console.log(error);
                });
        }

        function addToFavorite(id, position) {
            axios.get('/add-to-favorite/' + id + '/' + position)
                .then(function(response) {
                    console.log(response.data);
                })
                .catch(function(error) {
                    window.location.href = '/login';
                });
        }

        function timeAgo(date) {
            const locale = 'ar-EG'; // Use the Arabic locale
            const intervals = [{
                    name: 'year',
                    seconds: 31536000
                },
                {
                    name: 'month',
                    seconds: 2592000
                },
                {
                    name: 'week',
                    seconds: 604800
                },
                {
                    name: 'day',
                    seconds: 86400
                },
                {
                    name: 'hour',
                    seconds: 3600
                },
                {
                    name: 'minute',
                    seconds: 60
                },
                {
                    name: 'second',
                    seconds: 1
                }
            ];

            const secondsAgo = Math.floor((new Date() - new Date(date)) / 1000);
            for (let i = 0; i < intervals.length; i++) {
                const interval = intervals[i];
                const count = Math.floor(secondsAgo / interval.seconds);
                if (count >= 1) {
                    return new Intl.RelativeTimeFormat(locale, {
                            numeric: 'auto'
                        })
                        .format(-count, interval.name);
                }
            }
            return 'الآن';
        }

        // Make product as activation
        function markAsActivation(id) {
            this.setLastUse(id, 'product');
            axios.get('/set-product-as-activation/' + id)
                .then(function(response) {

                })
        }

        // Make product as activation
        function markAsInActivation(id) {
            this.setLastUse(id, 'product');
            axios.get('/set-product-as-inactivation/' + id)
                .then(function(response) {})
        }

        // Share Button
        function shareByEmail(product_name, price, discount) {
            // const subject = product_name;
            const body =
                `استخدم كود (${price}) للحصول على خصم العرض ${discount} في ${product_name} 😁\n\nحمل تطبيق كوبنز للحصول على أحدث كوبونات الخصم`;



            const phoneNumber =
                '+972567077653'; // Replace with the phone number you want to send the message to, including country code but without any symbols or spaces
            const message = 'Hello!'; // Replace with the message you want to send
            const whatsappLink = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(body)}`;
            window.location.href = whatsappLink;

            // const mailtoUrl =
            //     `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

            // window.location.href = mailtoUrl;
        }

        // Copy Element
        function copyCodeToClipboard(code, products) {
            navigator.clipboard.writeText(code);
            alert('Code copy successfully');
            // const el = document.createElement('textarea');
            // el.value = code;
            // document.body.appendChild(el);
            // el.select();
            // document.execCommand('copy');
            // document.body.removeChild(el);

            // const copiedEl = document.getElementById('copied');
            // copiedEl.classList.add('show');
            // setTimeout(() => {
            //     copiedEl.classList.remove('show');
            // }, 2000);
            this.setLastUse(products.id, 'product');
        }

        // Shopping Redirect
        function redirectShopping(url) {
            location.href = url;
        }

        // Shopping Redirect
        function redirectShopping(url) {
            location.href = url;
        }
    </script>

    <script>
        // Share Button
        function shareOffer(product, url) {
            // const subject = product.name;
            const body =
                `مرحبًا،\n\nأردت مشاركة هذا المنتج معك من ${product.name}: \n\ ${url}\n\nتفضل بزيارة هذا الرابط لعرض المنتج. \n\nشكرًا لك!`;

            // const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
            // window.location.href = mailtoUrl;

            const phoneNumber =
                '+972567077653'; // Replace with the phone number you want to send the message to, including country code but without any symbols or spaces
            const message = 'Hello!'; // Replace with the message you want to send
            const whatsappLink = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(body)}`;
            window.location.href = whatsappLink;
        }

        // Set Last Use
        function setLastUse(id, position) {
            axios.get('/set-last-use/' + id + '/' + position)
                .then(function(response) {
                    // console.log(response);
                });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\Coupons\resources\views/livewire/front/client/offers.blade.php ENDPATH**/ ?>