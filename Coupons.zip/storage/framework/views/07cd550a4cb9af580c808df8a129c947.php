<?php $__env->startSection('title', __('Create a artical')); ?>
<?php $__env->startSection('page-index', __('Articals')); ?>
<?php $__env->startSection('root', __('Create')); ?>
<?php $__env->startSection('sub-root', __('CM')); ?>


<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="validations" id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(__('Create a new artical')); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.articals.create', ['blogs' => $blogs])->html();
} elseif ($_instance->childHasBeenRendered('Xx1MJXL')) {
    $componentId = $_instance->getRenderedChildComponentId('Xx1MJXL');
    $componentTag = $_instance->getRenderedChildComponentTagName('Xx1MJXL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Xx1MJXL');
} else {
    $response = \Livewire\Livewire::mount('backend.articals.create', ['blogs' => $blogs]);
    $html = $response->html();
    $_instance->logRenderedChild('Xx1MJXL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('artical-created', function(data) {
                // alert(data.message);
                console.log('Here');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Coupons\resources\views/backend/articals/store.blade.php ENDPATH**/ ?>