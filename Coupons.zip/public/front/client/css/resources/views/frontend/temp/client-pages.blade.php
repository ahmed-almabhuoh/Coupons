@extends('frontend.layouts.client-pages')

@section('title', 'Page Title')

@section('styles')

@endsection

@section('content')

@endsection

@section('scripts')

@endsection
