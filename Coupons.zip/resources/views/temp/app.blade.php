@extends('layouts.app')

@section('title', 'Control Panel')
@section('page-index', 'Dashboard')
@section('root', 'Panel')
@section('sub-root', 'Manager')


@section('styles')

@endsection

@section('content')

@endsection

@section('scripts')

@endsection
