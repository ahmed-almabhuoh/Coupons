@extends('layouts.app')

@section('title', __('Control Panel'))
@section('page-index', __('Dashboard'))
@section('root', __('Panel'))
@section('sub-root', __('Manager'))


@section('styles')

@endsection

@section('content')

@endsection

@section('scripts')

@endsection
