<?php

namespace App\Http\Controllers;

use App\Models\Serial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

class SerialController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        if (!auth()->user()->can('view-serials')) {
            abort(403);
        }
        return response()->view('backend.serials.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!auth()->user()->can('create-serial')) {
            abort(403);
        }
        return response()->view('backend.serials.store');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Serial $serial)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!auth()->user()->can('edit-serial')) {
            abort(403);
        }
        return response()->view('backend.serials.edit', [
            'serial' => Serial::findOrFail(Crypt::decrypt($id)),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Serial $serial)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!auth()->user()->can('delete-serial')) {
            abort(403);
        }
        $serial = Serial::findOrFail(Crypt::decrypt($id));
        //
        if ($serial->delete()) {
            return response()->json([
                'header' => __('Success'),
                'body' => __('License deleted successfully'),
                'icon' => 'success',
                'title' => __('Success'),
                'text' => __('License number deleted successfully'),
            ], Response::HTTP_OK);
        } else {
            return response()->json([
                'header' => __('Failed!'),
                'body' => __('Failed to delete the serial license!'),
                'icon' => 'error',
                'title' =>  __('Failed!'),
                'text' =>  __('Failed to delete the serial license!'),
            ], Response::HTTP_BAD_REQUEST);
        }
    }

    // Manage License
    public function getLicensePage()
    {
        return response()->view('backend.client.license');
    }

    // Submit License
    public function submitLicense(Request $request)
    {
        $request->validate([
            'username' => 'required|string|exists:serials,username',
            'password' => 'required|string',
            'serial' => 'required|string|exists:serials,serial',
        ]);
        //

        $serial = Serial::where([
            ['serial', '=', $request->post('serial')],
            ['username', '=', $request->post('username')],
        ])->first();

        if (Hash::check($request->post('password'), $serial->password)) {
            // Generate the link, and send it to email

        } else {
            return redirect()->back();
        }
    }
}
